# Personal Expense Tracker

## Overview

A simple command-line application that tracks personal expenses.

## Features

- Input expense description and amount.
- Calculates total expenses.

## Technologies Used

- Ruby

## How to Run

1. Run the script: `ruby expense_tracker.rb`